package com.jprime.furnitureshop.service;

import com.jprime.furnitureshop.entity.ProductInOrder;
import com.jprime.furnitureshop.entity.User;

/**
 * Created By Zhu Lin on 1/3/2019.
 */
public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
