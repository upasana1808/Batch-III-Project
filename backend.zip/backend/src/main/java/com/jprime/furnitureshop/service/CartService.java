package com.jprime.furnitureshop.service;

import java.util.Collection;

import com.jprime.furnitureshop.entity.Cart;
import com.jprime.furnitureshop.entity.ProductInOrder;
import com.jprime.furnitureshop.entity.User;

/**
 * Created By Zhu Lin on 3/10/2018.
 */
public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
