CREATE DATABASE  IF NOT EXISTS `shoppingcart` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `shoppingcart`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: shoppingcart
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_info`
--

DROP TABLE IF EXISTS `product_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_info` (
  `product_id` varchar(255) NOT NULL,
  `category_type` int(11) DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `product_description` varchar(255) DEFAULT NULL,
  `product_icon` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` decimal(19,2) NOT NULL,
  `product_status` int(11) DEFAULT '0',
  `product_stock` int(11) NOT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_info`
--

LOCK TABLES `product_info` WRITE;
/*!40000 ALTER TABLE `product_info` DISABLE KEYS */;
INSERT INTO `product_info` VALUES ('B001',7,'2018-03-10 12:16:44','solid-wood-king-size-bed-with-drawer-storage-in-warm-chestnut-finish','https://ii1.pepperfry.com/media/catalog/product/a/v/494x544/avian-solid-wood-king-size-bed-with-drawer-storage-in-warm-chestnut-finish-by-woodsworth-avian-solid-najqdy.jpg','King Size Bed',299.00,0,25,'2018-03-10 12:16:44'),('B002',7,'2018-03-10 12:16:44','solid-wood-king-size-bed-with--box-storage-in-dual-tone','https://ii1.pepperfry.com/media/catalog/product/d/e/494x544/deux-solid-wood-king-size-bed-with--box-storage-in-dual-tone-by-woodsworth-deux-solid-wood-king-size-ktc76r.jpg','King Size Bed',357.00,0,17,'2018-03-10 12:16:44'),('B003',7,'2018-03-10 12:16:44','burlington-metallic-king-size-bed-with-storage-in-black-colour','https://ii1.pepperfry.com/media/catalog/product/b/u/494x544/burlington-metallic-king-size-bed-with-storage-in-black-colour-by-furniturekraft-burlington-metallic-krafgn.jpg','King Size Bed',270.00,1,0,'2018-03-10 12:16:44'),('B004',7,'2018-03-10 12:16:44','king-size-bed-with-headboard-box-storage-in-black-colour','https://ii1.pepperfry.com/media/catalog/product/t/o/494x544/torrie-king-size-bed-with-headboard---box-storage-in-black-colour-by--home-torrie-king-size-bed-with-ehafq6.jpg','King Size Bed',350.00,0,14,'2018-03-10 12:16:44'),('B005',7,'2018-03-10 12:16:44','king-size-bed-with-hydraulic-storage-in-dual-tone-finish','https://ii1.pepperfry.com/media/catalog/product/a/m/494x544/ambra-king-size-bed-with-hydraulic-storage-in-dual-tone-finish-by-hometown-ambra-king-size-bed-with--4cgfr4.jpg','King Size Bed',240.00,1,0,'2018-03-10 12:16:44'),('B006',7,'2018-03-10 12:16:44','king-size-bed-in-chocolate-finish','https://ii1.pepperfry.com/media/catalog/product/o/s/494x544/osumi-king-size-bed-in-chocolate-finish-by-mintwud-osumi-king-size-bed-in-chocolate-finish-by-mintwu-n2bhle.jpg','King Size Bed',300.00,0,8,'2018-03-10 12:16:44'),('D001',6,'2018-03-10 12:16:44','6-seater-dining-set-in-walnut-sky-blue-fini','https://ii1.pepperfry.com/media/catalog/product/h/a/494x544/haruka-6-seater-dining-set-in-walnut---sky-blue-finish-by-casacraft-haruka-6-seater-dining-set-in-wa-9vbvhl.jpg','6 Seater Dining Set',679.00,0,12,'2018-03-10 12:16:44'),('D002',6,'2018-03-10 12:16:44','solid-wood-six-seater-dining-set-with-bench-in-rustic-teak-finish',' https://ii1.pepperfry.com/media/catalog/product/o/r/494x544/oriel-solid-wood-six-seater-dining-set-with-bench-in-rustic-teak-finish-by-woodsworth-oriel-solid-wo-htveld.jpg','6 seater dining set with bench',629.00,0,4,'2018-03-10 12:16:44'),('D003',6,'2018-03-10 12:16:44','solid-wood-six-seater-dining-set-in-provincial-teak-finish','https://ii1.pepperfry.com/media/catalog/product/a/c/494x544/acropolis-solid-wood-six-seater-dining-set-in-provincial-teak-finish-by-woodsworth-acropolis-solid-w-oo1nh9.jpg','6 Seater Dining Set',500.00,0,16,'2018-03-10 12:16:44'),('D004',6,'2018-03-10 12:16:44','6-seater-silver-grey-velvet-dining-set','https://img.danetti.com/1000/clover-silver-grey-velvet-dining-chair/clover-silver-grey-velvet-dining-chair-5.jpg','6 Seater Dining Set',555.00,0,2,'2018-03-10 12:16:44'),('D005',6,'2018-03-10 12:16:44','s6-seater-dining-set-with-bench-in-white-colour','https://ii1.pepperfry.com/media/catalog/product/n/o/494x544/novo-six-seater-dining-set-with-bench-in-white-colour-by-bohemiana-novo-six-seater-dining-set-with-b-rryz2c.jpg','6 Seater Dining Set',450.00,0,16,'2018-03-10 12:16:44'),('D006',6,'2018-03-10 12:16:44','6-seater-dining-set-with-tempered-glass-top','https://ii1.pepperfry.com/media/catalog/product/m/i/494x544/micra-6-seater-dining-set-with-tempered-glass-top-by-royaloak-micra-6-seater-dining-set-with-tempere-j102yn.jpg','6 Seater Dining Set',425.00,1,0,'2018-03-10 12:16:44'),('S001',5,'2018-03-10 12:16:44','three-seater-sofa-in-garnet-red-colour','https://ii1.pepperfry.com/media/catalog/product/f/u/568x284/fuego-three-seater-sofa-in-garnet-red-colour-by-casacraft-fuego-three-seater-sofa-in-garnet-red-colo-62fqrt.jpg','3-Seater Sofa',263.00,0,20,'2018-03-10 12:16:44'),('S002',5,'2018-03-10 12:16:44','3-seater-sofa-in-blue-colour','https://ii1.pepperfry.com/media/catalog/product/a/m/568x284/amida-3-seater-sofa-in-blue-colour-by-mintwud-amida-3-seater-sofa-in-blue-colour-by-mintwud-q1ajby.jpg','3 Seater Sofa',320.00,0,21,'2018-03-10 12:16:44'),('S003',5,'2018-03-10 12:16:44','metallic-sofa-set--3---1---1--with-cobblestone-grey-mattress','https://ii1.pepperfry.com/media/catalog/product/v/i/568x284/vienna-metallic-sofa-set--3---1---1--with-cobblestone-grey-mattress---cushions-by-furniturekraft-vie-amwzkf.jpg','3+1+1 Sofa Set',120.00,0,15,'2018-03-10 12:16:44'),('S004',5,'2018-03-10 12:16:44','three-seater-sofa-in-maroon-colour','https://ii1.pepperfry.com/media/catalog/product/f/a/568x284/fabiana-three-seater-sofa-in-maroon-colour-by-casacraft-fabiana-three-seater-sofa-in-maroon-colour-b-f2uf0r.jpg','3 Seater Sofa',399.00,0,5,'2018-03-10 12:16:44'),('S005',5,'2018-03-10 12:16:44','3-Seater-Sofa-Greycolor','https://ii1.pepperfry.com/media/catalog/product/c/h/568x284/chestfield-three-seater-by-elizan-chestfield-three-seater-by-elizan-tsdwnh.jpg','3-Seater Sofa',329.00,0,9,'2018-03-10 12:16:44'),('S006',5,'2018-03-10 12:16:44','3-Seater-Sofa-Yellow Color','https://ii1.pepperfry.com/media/catalog/product/q/u/568x284/quince-fabric-three-seater-sofa-in-yellow-colour-by-russet-quince-fabric-three-seater-sofa-in-yellow-8saz6p.jpg','3-Seater Sofa',309.00,0,14,'2018-03-10 12:16:44'),('W001',4,'2018-03-10 12:16:44','2 door wardrobe','https://ii1.pepperfry.com/media/catalog/product/k/o/494x544/kosmo-coral-two-door-wardrobe-in-dual-tone-finish-by-spacewood-kosmo-coral-two-door-wardrobe-in-dual-kn0le3.jpg','2-door wardrobe',199.00,0,65,'2018-03-10 12:16:44'),('W002',4,'2018-03-10 12:16:44','four-door-hinged-wardrobe-with-bottom-drawer-storage-in-natural-teak-finish','https://ii3.pepperfry.com/media/catalog/product/n/i/494x544/nicole-four-door-hinged-wardrobe-with-bottom-drawer-storage-in-natural-teak-finish-by-casacraft-nico-09jemm.jpg','4-Door Wardrobe',450.00,0,12,'2018-03-10 12:16:44'),('W003',4,'2018-03-10 12:16:44','wardrobe-with-sliding-doors-in-natural-wenge-melamine-finish','https://ii1.pepperfry.com/media/catalog/product/k/o/494x544/kosmo-universal-wardrobe-with-sliding-doors-in-natural-wenge-melamine-finish-by-spacewood-kosmo-univ-92eecd.jpg','Sliding Door Wardrobe',360.00,0,4,'2018-03-10 12:16:44'),('W004',4,'2018-03-10 12:16:44','6 door wardrobe with external drawers in wenge finish','https://ii1.pepperfry.com/media/catalog/product/r/e/494x544/ren-6-door-wardrobe-with-external-drawers-in-wenge-finish-by-mintwud-ren-6-door-wardrobe-with-extern-wl5gz3.jpg','6-Door Wardrobe',429.00,0,30,'2018-03-10 12:16:44'),('W005',4,'2018-03-10 12:16:44','4 door wardrobe','https://ii1.pepperfry.com/media/catalog/product/p/r/494x544/prime-four-door-wardrobe-in-wenge-colour-by-hometown-prime-four-door-wardrobe-in-wenge-colour-by-hom-oixb4c.jpg','4-Door Wardrobe',350.00,0,30,'2018-03-10 12:16:44'),('W006',4,'2018-03-10 12:16:44','4 door wardrobe','https://ii1.pepperfry.com/media/catalog/product/k/o/494x544/kosmo-choco-four-door-wardrobe-in-vermont-finish-by-spacewood-kosmo-choco-four-door-wardrobe-in-verm-lc24ph.jpg','4-Door Wardrobe',369.00,1,0,'2018-03-10 12:16:44');
/*!40000 ALTER TABLE `product_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-17 10:29:05
