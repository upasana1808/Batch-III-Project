export enum CategoryType {
    "Books", "Food",  "Drink","Cloths","Wardrobe","Sofa Sets","Dining Sets","Beds"
}
